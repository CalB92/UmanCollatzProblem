UMANtec problem 1

The problem has been solved using the C programming language. The program will accept values between 0 and 5000000 for the upper limit. The starting number with the longest sequence will be displayed.
It was tested by using the command prompt to enter the parameter.